# HIT226 Sprint 3 MVP

## Project Brief
This project is a Student Support Card System designed as a simple ReactJS MVP for beginner university students. The application provides a small number of focused support actions through three interactive cards that deal with study planning, wellbeing, and support resources. The purpose of the design is to reduce overload, improve clarity, and help students make one useful decision at a time instead of navigating a full website.

## Design Summary
The design is based on the idea that first year students often feel overwhelmed by multiple deadlines, systems, and responsibilities. Instead of offering a large dashboard, the MVP limits interaction to a single page and three cards only. This keeps the interface aligned with the brief and makes the structure easier to test for responsiveness, accessibility, and clarity.

## Assumption and Hypothesis
This design assumes that beginner university students are more likely to engage with a support interface when it is visually clear, limited in scope, and directly useful. The hypothesis is that if students are shown only a few relevant support actions in a card layout, they will feel less overwhelmed and more confident about what to do next.

## User Persona
Simranpreet is a first year university student who is trying to manage study workload, assessment deadlines, and personal responsibilities at the same time. She wants a simple support interface that helps her decide what to do next without searching through multiple university systems. She values clarity, direct language, and interactions that feel lightweight rather than complex.

## AI Prompts Used
The following AI prompts were used as drafting support while the design decisions were revised manually for this project.

1. Create a ReactJS MVP with three interactive cards for a Student Support Card System.
2. Refine the interface so it is mobile first, accessible, and visually distinct from a generic template.
3. Write a short project brief, persona, assumption, and hypothesis for the README.
4. Prepare a report style summary based on the worksheet requirements for Sprint 3.
5. Suggest a Bitbucket ready repository structure with an application folder and build files copied to the top directory.

## Repository Structure
The application folder contains the React source code.  
The build folder contains the static output that was copied to the repository root for bitbucket.io hosting.  
The root index.html and assets folder are the live files used by the hosted site.

## Setup Instructions
This repository contains both the React application source and the static hosting files.

To work on the React source:
1. open the application folder
2. run npm install
3. run npm run dev for local development
4. run npm run build when you need a new production build

For the live repository:
the contents of the build folder should be copied to the top directory so the bitbucket.io site can run from the root.
