# Sprint 3 Report Summary

This file is a working report summary template aligned with the worksheet. It should be expanded and submitted with the completed worksheet content.

## Problem Context
The MVP focuses on the issue that many beginner university students feel overloaded by deadlines, study pressure, and multiple disconnected systems.

## Design Response
The design response was to reduce complexity rather than add more features. For that reason, the MVP uses a single page and only three cards.

## Information Architecture
The page begins with an introduction, then a short overview strip, followed by the three interactive cards, and a short reflection section. The structure is intentionally shallow so the user can reach the most relevant actions immediately.

## Hypothesis
If students are shown only a small number of relevant support actions in a clear card layout, they will feel less overwhelmed and more confident about what to do next.

## Why the Design Is Limited
This MVP is not intended to be a full website. It is a card system template designed to test layout, interaction, responsiveness, and accessibility.
