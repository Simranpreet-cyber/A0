import { useState } from 'react'
import { plannerItems, wellbeingItems, resourceItems } from './content'

function ActionCard({ title, tag, intro, bullets, currentValue, buttonLabel, onChange, accent }) {
  return (
    <article className={`action-card ${accent}`}>
      <div className="card-header">
        <div>
          <p className="card-tag">{tag}</p>
          <h2>{title}</h2>
        </div>
        <div className="dot-group" aria-hidden="true">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>

      <p className="card-intro">{intro}</p>

      <ul className="bullet-list">
        {bullets.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>

      <div className="result-panel" aria-live="polite">
        <p className="result-label">Current action</p>
        <p className="result-value">{currentValue}</p>
      </div>

      <button className="card-button" onClick={onChange} type="button">
        {buttonLabel}
      </button>
    </article>
  )
}

export default function App() {
  const [plannerIndex, setPlannerIndex] = useState(0)
  const [wellbeingIndex, setWellbeingIndex] = useState(0)
  const [resourceIndex, setResourceIndex] = useState(0)

  return (
    <main className="page">
      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">HIT226 Sprint 3 MVP</p>
          <h1>Student Support Card System</h1>
          <p className="lead">
            This ReactJS MVP uses a small card system to support beginner university students.
            It focuses on simple actions, low effort interaction, and clear decision making
            rather than a full website or dashboard.
          </p>
        </div>

        <aside className="hero-note">
          <p className="note-title">Design intention</p>
          <p>
            The design is built around the idea that first year students often feel overloaded.
            Instead of showing too much information, the interface limits the user to three support choices only.
          </p>
        </aside>
      </section>

      <section className="overview-strip" aria-labelledby="overview-title">
        <div className="overview-card">
          <p className="small-label">User</p>
          <h2 id="overview-title">Beginner university students under study pressure</h2>
        </div>
        <div className="overview-card">
          <p className="small-label">Hypothesis</p>
          <p className="plain-text">
            If students are shown only a few relevant support actions in a card layout,
            they will feel less overwhelmed and more confident about what to do next.
          </p>
        </div>
      </section>

      <section className="cards" aria-label="Student support cards">
        <ActionCard
          title="Study Planner"
          tag="Task Focus"
          intro="This card narrows study attention to one manageable action so the user can start instead of freeze."
          bullets={["Reduce study confusion", "Promote one step at a time", "Encourage practical planning"]}
          currentValue={plannerItems[plannerIndex]}
          buttonLabel="Change Focus"
          onChange={() => setPlannerIndex((plannerIndex + 1) % plannerItems.length)}
          accent="accent-blue"
        />

        <ActionCard
          title="Wellbeing Check"
          tag="Reset Prompt"
          intro="This card interrupts stress spirals with small reset actions that feel realistic during a busy week."
          bullets={["Encourage pause and reset", "Reduce overwhelm", "Support emotional confidence"]}
          currentValue={wellbeingItems[wellbeingIndex]}
          buttonLabel="Check In"
          onChange={() => setWellbeingIndex((wellbeingIndex + 1) % wellbeingItems.length)}
          accent="accent-purple"
        />

        <ActionCard
          title="Support Resources"
          tag="Help Path"
          intro="This card points the student to the most useful support channel without making them search everywhere."
          bullets={["Academic help", "Library help", "Wellbeing help", "IT help"]}
          currentValue={resourceItems[resourceIndex]}
          buttonLabel="Show Help Option"
          onChange={() => setResourceIndex((resourceIndex + 1) % resourceItems.length)}
          accent="accent-green"
        />
      </section>

      <section className="reflection" aria-labelledby="reflection-title">
        <div className="reflection-card">
          <p className="small-label">Original design choice</p>
          <h2 id="reflection-title">Why this is not a full website</h2>
          <p>
            The MVP is intentionally limited to one page and three cards. That keeps the design aligned
            with the brief and makes the interaction system clearer to test for accessibility, responsiveness,
            and user understanding.
          </p>
        </div>
      </section>

      <footer className="site-footer">
        <p><strong>Student:</strong> Simranpreet Kaur</p>
        <p><strong>Project:</strong> Student Support Card System</p>
        <p><strong>Submission note:</strong> This MVP is a single DOM with three cards only.</p>
      </footer>
    </main>
  )
}
