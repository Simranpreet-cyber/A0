export const plannerItems = [
  "Block 20 minutes to review lecture notes before dinner.",
  "List one assessment task and break it into two smaller steps.",
  "Move one unfinished task into tomorrow's study window.",
  "Use a short checklist instead of trying to remember everything."
]

export const wellbeingItems = [
  "Take a five minute pause and breathe slowly before the next task.",
  "Stand up, stretch, and reset your shoulders and neck.",
  "Swap one negative thought for one practical next step.",
  "If stress is building, reach out for support early."
]

export const resourceItems = [
  "Academic Skills can help with structure, writing, and referencing.",
  "Library support can guide you to readings, databases, and research help.",
  "Student wellbeing services can support stress, pressure, and balance.",
  "The IT Help Desk can fix access problems before they affect your study."
]
