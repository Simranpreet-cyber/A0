const e = React.createElement;
const { useState } = React;

const plannerItems = [
  "Block 20 minutes to review lecture notes before dinner.",
  "List one assessment task and break it into two smaller steps.",
  "Move one unfinished task into tomorrow's study window.",
  "Use a short checklist instead of trying to remember everything."
];

const wellbeingItems = [
  "Take a five minute pause and breathe slowly before the next task.",
  "Stand up, stretch, and reset your shoulders and neck.",
  "Swap one negative thought for one practical next step.",
  "If stress is building, reach out for support early."
];

const resourceItems = [
  "Academic Skills can help with structure, writing, and referencing.",
  "Library support can guide you to readings, databases, and research help.",
  "Student wellbeing services can support stress, pressure, and balance.",
  "The IT Help Desk can fix access problems before they affect your study."
];

function ActionCard(props) {
  return e(
    "article",
    { className: `action-card ${props.accent}` },
    e(
      "div",
      { className: "card-header" },
      e(
        "div",
        null,
        e("p", { className: "card-tag" }, props.tag),
        e("h2", null, props.title)
      ),
      e(
        "div",
        { className: "dot-group", "aria-hidden": "true" },
        e("span"),
        e("span"),
        e("span")
      )
    ),
    e("p", { className: "card-intro" }, props.intro),
    e(
      "ul",
      { className: "bullet-list" },
      ...props.bullets.map((item, index) => e("li", { key: index }, item))
    ),
    e(
      "div",
      { className: "result-panel", "aria-live": "polite" },
      e("p", { className: "result-label" }, "Current action"),
      e("p", { className: "result-value" }, props.currentValue)
    ),
    e(
      "button",
      { className: "card-button", onClick: props.onChange, type: "button" },
      props.buttonLabel
    )
  );
}

function App() {
  const [plannerIndex, setPlannerIndex] = useState(0);
  const [wellbeingIndex, setWellbeingIndex] = useState(0);
  const [resourceIndex, setResourceIndex] = useState(0);

  return e(
    "main",
    { className: "page" },
    e(
      "section",
      { className: "hero" },
      e(
        "div",
        { className: "hero-copy" },
        e("p", { className: "eyebrow" }, "HIT226 Sprint 3 MVP"),
        e("h1", null, "Student Support Card System"),
        e(
          "p",
          { className: "lead" },
          "This ReactJS MVP uses a small card system to support beginner university students. It focuses on simple actions, low effort interaction, and clear decision making rather than a full website or dashboard."
        )
      ),
      e(
        "aside",
        { className: "hero-note" },
        e("p", { className: "note-title" }, "Design intention"),
        e(
          "p",
          null,
          "The design is built around the idea that first year students often feel overloaded. Instead of showing too much information, the interface limits the user to three support choices only."
        )
      )
    ),
    e(
      "section",
      { className: "overview-strip", "aria-labelledby": "overview-title" },
      e(
        "div",
        { className: "overview-card" },
        e("p", { className: "small-label" }, "User"),
        e("h2", { id: "overview-title" }, "Beginner university students under study pressure")
      ),
      e(
        "div",
        { className: "overview-card" },
        e("p", { className: "small-label" }, "Hypothesis"),
        e(
          "p",
          { className: "plain-text" },
          "If students are shown only a few relevant support actions in a card layout, they will feel less overwhelmed and more confident about what to do next."
        )
      )
    ),
    e(
      "section",
      { className: "cards", "aria-label": "Student support cards" },
      e(ActionCard, {
        title: "Study Planner",
        tag: "Task Focus",
        intro: "This card narrows study attention to one manageable action so the user can start instead of freeze.",
        bullets: ["Reduce study confusion", "Promote one step at a time", "Encourage practical planning"],
        currentValue: plannerItems[plannerIndex],
        buttonLabel: "Change Focus",
        onChange: () => setPlannerIndex((plannerIndex + 1) % plannerItems.length),
        accent: "accent-blue"
      }),
      e(ActionCard, {
        title: "Wellbeing Check",
        tag: "Reset Prompt",
        intro: "This card interrupts stress spirals with small reset actions that feel realistic during a busy week.",
        bullets: ["Encourage pause and reset", "Reduce overwhelm", "Support emotional confidence"],
        currentValue: wellbeingItems[wellbeingIndex],
        buttonLabel: "Check In",
        onChange: () => setWellbeingIndex((wellbeingIndex + 1) % wellbeingItems.length),
        accent: "accent-purple"
      }),
      e(ActionCard, {
        title: "Support Resources",
        tag: "Help Path",
        intro: "This card points the student to the most useful support channel without making them search everywhere.",
        bullets: ["Academic help", "Library help", "Wellbeing help", "IT help"],
        currentValue: resourceItems[resourceIndex],
        buttonLabel: "Show Help Option",
        onChange: () => setResourceIndex((resourceIndex + 1) % resourceItems.length),
        accent: "accent-green"
      })
    ),
    e(
      "section",
      { className: "reflection", "aria-labelledby": "reflection-title" },
      e(
        "div",
        { className: "reflection-card" },
        e("p", { className: "small-label" }, "Original design choice"),
        e("h2", { id: "reflection-title" }, "Why this is not a full website"),
        e(
          "p",
          null,
          "The MVP is intentionally limited to one page and three cards. That keeps the design aligned with the brief and makes the interaction system clearer to test for accessibility, responsiveness, and user understanding."
        )
      )
    ),
    e(
      "footer",
      { className: "site-footer" },
      e("p", null, e("strong", null, "Student: "), "Simranpreet Kaur"),
      e("p", null, e("strong", null, "Project: "), "Student Support Card System"),
      e("p", null, e("strong", null, "Submission note: "), "This MVP is a single DOM with three cards only.")
    )
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(e(App));
